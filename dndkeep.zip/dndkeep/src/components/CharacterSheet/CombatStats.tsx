import { useState } from 'react';
import type { Character, ComputedStats } from '../../types';
import { formatModifier } from '../../lib/gameUtils';

interface CombatStatsProps {
  character: Character;
  computed: ComputedStats;
  onUpdateHP: (currentHp: number, tempHp: number) => void;
  onUpdate: (updates: Partial<Character>) => void;
}

function HPBar({ current, max }: { current: number; max: number }) {
  const pct = max > 0 ? Math.max(0, Math.min(1, current / max)) : 0;
  const color = pct > 0.5 ? 'var(--hp-full)'
              : pct > 0.25 ? 'var(--hp-mid)'
              : current > 0 ? 'var(--hp-low)'
              : 'var(--hp-dead)';
  return (
    <div className="hp-bar-container" style={{ marginTop: 'var(--space-2)' }}>
      <div className="hp-bar-fill" style={{ width: `${pct * 100}%`, background: color }} />
    </div>
  );
}

/** A stat box that switches to an inline number input on click. */
function EditableStatBox({
  label, value, unit, min = 0, max = 999,
  format, onCommit,
}: {
  label: string;
  value: number;
  unit?: string;
  min?: number;
  max?: number;
  format?: (v: number) => string;
  onCommit: (v: number) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState('');

  function open() {
    setDraft(String(value));
    setEditing(true);
  }

  function commit() {
    const parsed = parseInt(draft, 10);
    if (!isNaN(parsed)) onCommit(Math.min(max, Math.max(min, parsed)));
    setEditing(false);
  }

  return (
    <div
      className="stat-box"
      onClick={!editing ? open : undefined}
      style={{ cursor: editing ? 'default' : 'pointer' }}
      title={editing ? undefined : `Click to edit ${label.toLowerCase()}`}
    >
      <div className="stat-box-label">{label}</div>
      {editing ? (
        <input
          type="number"
          value={draft}
          min={min}
          max={max}
          autoFocus
          onChange={e => setDraft(e.target.value)}
          onBlur={commit}
          onKeyDown={e => { if (e.key === 'Enter') commit(); if (e.key === 'Escape') setEditing(false); }}
          style={{
            width: '3rem',
            textAlign: 'center',
            fontFamily: 'var(--font-heading)',
            fontWeight: 700,
            fontSize: 'var(--text-xl)',
            background: 'var(--bg-sunken)',
            border: '1px solid var(--border-gold)',
            borderRadius: 'var(--radius-sm)',
            color: 'var(--text-primary)',
            padding: '2px 4px',
          }}
          onClick={e => e.stopPropagation()}
        />
      ) : (
        <div className="stat-box-value">{format ? format(value) : value}</div>
      )}
      {unit && <div style={{ fontSize: 'var(--text-xs)', color: 'var(--text-muted)' }}>{unit}</div>}
    </div>
  );
}

export default function CombatStats({ character, computed, onUpdateHP, onUpdate }: CombatStatsProps) {
  const [hpDelta, setHpDelta] = useState('');
  const [mode, setMode] = useState<'damage' | 'heal' | 'temp'>('damage');

  const hpPct = character.max_hp > 0 ? Math.max(0, character.current_hp / character.max_hp) : 0;
  const hpColor = hpPct > 0.5 ? 'var(--hp-full)'
                : hpPct > 0.25 ? 'var(--hp-mid)'
                : character.current_hp > 0 ? 'var(--hp-low)'
                : 'var(--hp-dead)';

  function applyDelta() {
    const value = parseInt(hpDelta, 10);
    if (isNaN(value) || value <= 0) return;

    if (mode === 'temp') {
      onUpdateHP(character.current_hp, Math.max(character.temp_hp, value));
    } else if (mode === 'damage') {
      const absorbed = Math.min(character.temp_hp, value);
      const remainder = value - absorbed;
      onUpdateHP(Math.max(0, character.current_hp - remainder), Math.max(0, character.temp_hp - absorbed));
    } else {
      onUpdateHP(Math.min(character.max_hp, character.current_hp + value), character.temp_hp);
    }
    setHpDelta('');
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Enter') applyDelta();
  }

  return (
    <section>
      <div className="section-header">Combat</div>

      {/* Editable stat grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 'var(--space-3)', marginBottom: 'var(--space-4)' }}>
        <EditableStatBox
          label="AC"
          value={character.armor_class}
          min={1} max={30}
          onCommit={v => onUpdate({ armor_class: v })}
        />
        <div className="stat-box" title="Initiative = DEX modifier + Initiative Bonus (editable below)">
          <div className="stat-box-label">Initiative</div>
          <div className="stat-box-value">{formatModifier(computed.initiative)}</div>
        </div>
        <EditableStatBox
          label="Speed"
          value={character.speed}
          unit="ft"
          min={0} max={999}
          onCommit={v => onUpdate({ speed: v })}
        />
        <div className="stat-box">
          <div className="stat-box-label">Prof. Bonus</div>
          <div className="stat-box-value">{formatModifier(computed.proficiency_bonus)}</div>
        </div>
      </div>

      {/* Secondary editable row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 'var(--space-3)', marginBottom: 'var(--space-4)' }}>
        <EditableStatBox
          label="Max HP"
          value={character.max_hp}
          min={1} max={9999}
          onCommit={v => {
            const newCurrent = Math.min(character.current_hp, v);
            onUpdate({ max_hp: v, current_hp: newCurrent });
          }}
        />
        <EditableStatBox
          label="Initiative Bonus"
          value={character.initiative_bonus}
          min={-10} max={20}
          format={formatModifier}
          onCommit={v => onUpdate({ initiative_bonus: v })}
        />
      </div>

      {/* HP Block */}
      <div className="panel" style={{ marginBottom: 'var(--space-4)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 'var(--space-1)' }}>
          <span style={{ fontFamily: 'var(--font-heading)', fontSize: 'var(--text-xs)', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--text-muted)' }}>
            Hit Points
          </span>
          <span style={{ fontFamily: 'var(--font-heading)', fontSize: 'var(--text-xs)', color: 'var(--text-muted)' }}>
            Max {character.max_hp}
          </span>
        </div>

        <div style={{ display: 'flex', alignItems: 'baseline', gap: 'var(--space-2)', margin: 'var(--space-2) 0' }}>
          <span style={{ fontFamily: 'var(--font-heading)', fontSize: 'var(--text-3xl)', fontWeight: 700, color: hpColor, lineHeight: 1 }}>
            {character.current_hp}
          </span>
          <span style={{ color: 'var(--text-muted)', fontSize: 'var(--text-lg)' }}>/ {character.max_hp}</span>
          {character.temp_hp > 0 && (
            <span style={{ marginLeft: 'var(--space-2)', fontFamily: 'var(--font-heading)', fontSize: 'var(--text-sm)', color: '#60a5fa', background: 'rgba(96,165,250,0.1)', border: '1px solid rgba(96,165,250,0.3)', borderRadius: 'var(--radius-sm)', padding: '0 var(--space-2)' }}>
              +{character.temp_hp} tmp
            </span>
          )}
        </div>

        <HPBar current={character.current_hp} max={character.max_hp} />

        {/* HP Adjustment Controls */}
        <div style={{ display: 'flex', gap: 'var(--space-2)', marginTop: 'var(--space-3)', alignItems: 'center', flexWrap: 'wrap' }}>
          {(['damage', 'heal', 'temp'] as const).map(m => (
            <button
              key={m}
              className={`btn-sm ${mode === m
                ? m === 'damage' ? 'btn-danger' : m === 'heal' ? 'btn-gold' : 'btn-secondary'
                : 'btn-secondary'
              }`}
              onClick={() => setMode(m)}
              style={mode === m && m === 'temp' ? { borderColor: '#60a5fa', color: '#60a5fa' } : {}}
            >
              {m === 'temp' ? 'Temp HP' : m.charAt(0).toUpperCase() + m.slice(1)}
            </button>
          ))}
          <input
            type="number"
            min="1"
            value={hpDelta}
            onChange={e => setHpDelta(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Amt"
            style={{ width: '68px', textAlign: 'center' }}
          />
          <button className="btn-primary btn-sm" onClick={applyDelta} disabled={!hpDelta}>
            Apply
          </button>
        </div>
      </div>

      {/* Passive perception + spellcasting stats */}
      {(() => {
        const colCount = 1
          + (computed.spell_save_dc    != null ? 1 : 0)
          + (computed.spell_attack_bonus != null ? 1 : 0);
        return (
          <div style={{ display: 'grid', gridTemplateColumns: `repeat(${colCount}, 1fr)`, gap: 'var(--space-3)' }}>
            <div className="stat-box">
              <div className="stat-box-label">Passive Perception</div>
              <div className="stat-box-value">{computed.passive_perception}</div>
            </div>
            {computed.spell_save_dc != null && (
              <div className="stat-box">
                <div className="stat-box-label">Spell Save DC</div>
                <div className="stat-box-value">{computed.spell_save_dc}</div>
              </div>
            )}
            {computed.spell_attack_bonus != null && (
              <div className="stat-box">
                <div className="stat-box-label">Spell Attack</div>
                <div className="stat-box-value">{formatModifier(computed.spell_attack_bonus)}</div>
              </div>
            )}
          </div>
        );
      })()}
    </section>
  );
}
