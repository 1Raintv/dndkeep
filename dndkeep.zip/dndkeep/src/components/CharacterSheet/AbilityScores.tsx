import { useState } from 'react';
import type { Character, ComputedStats, AbilityKey } from '../../types';
import { abilityAbbrev, formatModifier, abilityModifier } from '../../lib/gameUtils';

interface AbilityScoresProps {
  character: Character;
  computed: ComputedStats;
  onUpdate: (updates: Partial<Character>) => void;
}

const ABILITY_ORDER: AbilityKey[] = [
  'strength', 'dexterity', 'constitution',
  'intelligence', 'wisdom', 'charisma',
];

function AbilityBox({
  ability, score, mod, save, onCommit, onToggleSave,
}: {
  ability: AbilityKey;
  score: number;
  mod: number;
  save: { total: number; proficient: boolean };
  onCommit: (ability: AbilityKey, value: number) => void;
  onToggleSave: (ability: AbilityKey) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState('');

  const previewMod = editing ? abilityModifier(parseInt(draft, 10) || score) : mod;

  function open() { setDraft(String(score)); setEditing(true); }

  function commit() {
    const parsed = parseInt(draft, 10);
    if (!isNaN(parsed) && parsed >= 1 && parsed <= 30) onCommit(ability, parsed);
    setEditing(false);
  }

  return (
    <div
      className="stat-box"
      style={{ gap: 'var(--space-2)', cursor: editing ? 'default' : 'pointer' }}
      onClick={!editing ? open : undefined}
      title={editing ? undefined : `Click to edit ${ability}`}
    >
      <div className="stat-box-label">{abilityAbbrev(ability)}</div>

      {/* Modifier — live preview while editing */}
      <div
        className="stat-box-modifier"
        style={{ color: editing ? 'var(--color-amber)' : undefined }}
      >
        {formatModifier(previewMod)}
      </div>

      {/* Score — inline input when editing */}
      {editing ? (
        <input
          type="number"
          value={draft}
          min={1} max={30}
          autoFocus
          onChange={e => setDraft(e.target.value)}
          onBlur={commit}
          onKeyDown={e => {
            if (e.key === 'Enter') commit();
            if (e.key === 'Escape') setEditing(false);
          }}
          onClick={e => e.stopPropagation()}
          style={{
            width: '3rem', textAlign: 'center',
            fontFamily: 'var(--font-heading)', fontWeight: 700,
            fontSize: 'var(--text-xl)',
            background: 'var(--bg-sunken)',
            border: '1px solid var(--border-gold)',
            borderRadius: 'var(--radius-sm)',
            color: 'var(--text-primary)',
            padding: '2px 4px',
          }}
        />
      ) : (
        <div className="stat-box-value">{score}</div>
      )}

      {/* Saving throw — click dot to toggle proficiency */}
      <div
        role="button"
        tabIndex={0}
        onClick={e => { e.stopPropagation(); onToggleSave(ability); }}
        onKeyDown={e => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.stopPropagation();
            onToggleSave(ability);
          }
        }}
        title={
          save.proficient
            ? `${abilityAbbrev(ability)} saving throw — proficient (click to remove)`
            : `${abilityAbbrev(ability)} saving throw — click to add proficiency`
        }
        style={{
          display: 'flex', alignItems: 'center', gap: 'var(--space-1)',
          marginTop: 'var(--space-1)', cursor: 'pointer', userSelect: 'none',
        }}
      >
        <span
          className={`prof-dot ${save.proficient ? 'proficient' : ''}`}
          style={{ pointerEvents: 'none' }}
        />
        <span style={{
          fontSize: 'var(--text-xs)',
          color: save.proficient ? 'var(--text-gold)' : 'var(--text-muted)',
          fontFamily: 'var(--font-heading)',
        }}>
          Save {formatModifier(save.total)}
        </span>
      </div>
    </div>
  );
}

export default function AbilityScores({ character, computed, onUpdate }: AbilityScoresProps) {
  function handleCommit(ability: AbilityKey, value: number) {
    onUpdate({ [ability]: value });
  }

  function handleToggleSave(ability: AbilityKey) {
    const current = character.saving_throw_proficiencies;
    onUpdate({
      saving_throw_proficiencies: current.includes(ability)
        ? current.filter(a => a !== ability)
        : [...current, ability],
    });
  }

  return (
    <section>
      <div className="section-header">Ability Scores</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 'var(--space-3)' }}>
        {ABILITY_ORDER.map(ability => (
          <AbilityBox
            key={ability}
            ability={ability}
            score={character[ability]}
            mod={computed.modifiers[ability]}
            save={computed.saving_throws[ability]}
            onCommit={handleCommit}
            onToggleSave={handleToggleSave}
          />
        ))}
      </div>
      <p style={{
        marginTop: 'var(--space-2)',
        fontSize: 'var(--text-xs)',
        color: 'var(--text-muted)',
        fontFamily: 'var(--font-heading)',
        letterSpacing: '0.04em',
      }}>
        Click score to edit (1–30). Click Save to toggle proficiency.
      </p>
    </section>
  );
}
