import type { Character, ComputedStats } from '../../types';
import { SKILLS } from '../../data/skills';
import { abilityAbbrev, formatModifier } from '../../lib/gameUtils';

interface SkillsListProps {
  character: Character;
  computed: ComputedStats;
  onUpdate: (updates: Partial<Character>) => void;
}

export default function SkillsList({ character, computed, onUpdate }: SkillsListProps) {
  const sortedSkills = [...SKILLS].sort((a, b) => a.name.localeCompare(b.name));

  /**
   * Cycle: none → proficient → expert → none
   * Expert requires proficiency first; removing proficiency also removes expertise.
   */
  function cycleSkill(skillName: string) {
    const isProf   = character.skill_proficiencies.includes(skillName);
    const isExpert = character.skill_expertises.includes(skillName);

    let newProf   = [...character.skill_proficiencies];
    let newExpert = [...character.skill_expertises];

    if (!isProf && !isExpert) {
      // none → proficient
      newProf = [...newProf, skillName];
    } else if (isProf && !isExpert) {
      // proficient → expert
      newExpert = [...newExpert, skillName];
    } else {
      // expert → none (remove both)
      newProf   = newProf.filter(s => s !== skillName);
      newExpert = newExpert.filter(s => s !== skillName);
    }

    onUpdate({ skill_proficiencies: newProf, skill_expertises: newExpert });
  }

  return (
    <section>
      <div className="section-header">Skills</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '3px' }}>
        {sortedSkills.map(skill => {
          const data = computed.skills[skill.name];
          if (!data) return null;

          const dotClass = data.expert
            ? 'prof-dot expert'
            : data.proficient
            ? 'prof-dot proficient'
            : 'prof-dot';

          const cycleTitle = data.expert
            ? `${skill.name}: Expert — click to remove`
            : data.proficient
            ? `${skill.name}: Proficient — click for Expertise`
            : `${skill.name}: Not proficient — click to add`;

          return (
            <div
              key={skill.name}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 'var(--space-2)',
                padding: '4px var(--space-3)',
                borderRadius: 'var(--radius-sm)',
                background: data.proficient ? 'rgba(201,146,42,0.05)' : 'transparent',
                transition: 'background var(--transition-fast)',
              }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLDivElement).style.background = 'var(--bg-raised)';
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLDivElement).style.background =
                  data.proficient ? 'rgba(201,146,42,0.05)' : 'transparent';
              }}
            >
              {/* Clickable proficiency dot */}
              <button
                onClick={() => cycleSkill(skill.name)}
                title={cycleTitle}
                style={{
                  background: 'none',
                  border: 'none',
                  padding: 0,
                  cursor: 'pointer',
                  flexShrink: 0,
                  display: 'inline-flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  width: 16,
                  height: 16,
                }}
              >
                <span className={dotClass} style={{ pointerEvents: 'none' }} />
              </button>

              <span style={{
                fontFamily: 'var(--font-heading)',
                fontWeight: 600,
                fontSize: 'var(--text-sm)',
                color: data.expert
                  ? 'var(--color-amber)'
                  : data.proficient
                  ? 'var(--text-primary)'
                  : 'var(--text-secondary)',
                flex: 1,
              }}>
                {skill.name}
              </span>

              <span style={{
                fontSize: 'var(--text-xs)',
                color: 'var(--text-muted)',
                fontFamily: 'var(--font-heading)',
              }}>
                {abilityAbbrev(skill.ability)}
              </span>

              <span style={{
                fontFamily: 'var(--font-heading)',
                fontWeight: 700,
                fontSize: 'var(--text-sm)',
                color: data.expert
                  ? 'var(--color-amber)'
                  : data.proficient
                  ? 'var(--text-gold)'
                  : 'var(--text-secondary)',
                minWidth: '2rem',
                textAlign: 'right',
              }}>
                {formatModifier(data.total)}
              </span>
            </div>
          );
        })}
      </div>

      {/* Legend */}
      <div style={{
        marginTop: 'var(--space-3)',
        display: 'flex',
        gap: 'var(--space-4)',
        fontSize: 'var(--text-xs)',
        color: 'var(--text-muted)',
        fontFamily: 'var(--font-heading)',
      }}>
        <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <span className="prof-dot" /> None
        </span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <span className="prof-dot proficient" /> Proficient
        </span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <span className="prof-dot expert" /> Expertise
        </span>
        <span style={{ color: 'var(--text-muted)', fontStyle: 'italic', marginLeft: 'auto' }}>
          Click dot to cycle
        </span>
      </div>
    </section>
  );
}
