import { useState, useEffect } from 'react';
import type { Campaign, Character, CampaignMember } from '../../types';
import { useCampaign } from '../../context/CampaignContext';
import { useAuth } from '../../context/AuthContext';
import {
  getCharactersByCampaign,
  getCampaignMembers,
  lookupProfileByEmail,
  addCampaignMember,
  removeCampaignMember,
  type MemberWithProfile,
} from '../../lib/supabase';

interface CampaignDashboardProps {
  campaign: Campaign;
  onBack: () => void;
}

export default function CampaignDashboard({ campaign, onBack }: CampaignDashboardProps) {
  const { user } = useAuth();
  const { sessionState, updateSessionState } = useCampaign();
  const [members, setMembers] = useState<(CampaignMember & { display_name: string | null; email: string })[]>([]);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviting, setInviting] = useState(false);
  const [inviteError, setInviteError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'members' | 'characters' | 'session'>('members');

  const isOwner = campaign.owner_id === user?.id;

  useEffect(() => {
    loadMembers();
    loadCharacters();
  }, [campaign.id]);

  async function loadMembers() {
    const { data } = await getCampaignMembers(campaign.id);
    setMembers(data.map((m: MemberWithProfile) => ({
      ...m,
      display_name: m.profiles?.display_name ?? null,
      email: m.profiles?.email ?? '',
    })));
  }

  async function loadCharacters() {
    const { data } = await getCharactersByCampaign(campaign.id);
    setCharacters(data);
  }

  async function handleInvite(e: React.FormEvent) {
    e.preventDefault();
    if (!inviteEmail.trim()) return;
    setInviting(true);
    setInviteError(null);

    const { data: found, error: lookupErr } = await lookupProfileByEmail(inviteEmail);
    if (lookupErr || !found) {
      setInviteError('No DNDKeep account found for that email address.');
      setInviting(false);
      return;
    }

    const { error } = await addCampaignMember(campaign.id, found.id);
    if (error) setInviteError(error.message);
    else { setInviteEmail(''); await loadMembers(); }
    setInviting(false);
  }

  async function removeMember(userId: string) {
    if (userId === campaign.owner_id) return;
    await removeCampaignMember(campaign.id, userId);
    await loadMembers();
  }

  async function toggleCombat() {
    await updateSessionState({ combat_active: !sessionState?.combat_active });
  }

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-4)', marginBottom: 'var(--space-6)' }}>
        <button className="btn-ghost btn-sm" onClick={onBack}>Back</button>
        <div style={{ flex: 1 }}>
          <h2 style={{ marginBottom: 'var(--space-1)' }}>{campaign.name}</h2>
          {campaign.setting && (
            <p style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)', fontFamily: 'var(--font-heading)' }}>
              {campaign.setting}
            </p>
          )}
        </div>
        <div style={{ display: 'flex', gap: 'var(--space-2)', alignItems: 'center' }}>
          {sessionState?.combat_active && (
            <span className="badge badge-crimson" style={{ animation: 'pulse-gold 2s infinite' }}>
              Combat Active — Round {sessionState.round}
            </span>
          )}
          {isOwner && (
            <button
              className={sessionState?.combat_active ? 'btn-danger btn-sm' : 'btn-primary btn-sm'}
              onClick={toggleCombat}
            >
              {sessionState?.combat_active ? 'End Combat' : 'Start Combat'}
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="tabs">
        {(['members', 'characters', 'session'] as const).map(tab => (
          <button key={tab} className={`tab ${activeTab === tab ? 'active' : ''}`} onClick={() => setActiveTab(tab)}>
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      <div key={activeTab} className="animate-fade-in">
        {/* Members tab */}
        {activeTab === 'members' && (
          <div style={{ maxWidth: 600 }}>
            {isOwner && (
              <form onSubmit={handleInvite} style={{ display: 'flex', gap: 'var(--space-3)', marginBottom: 'var(--space-6)' }}>
                <input
                  type="email"
                  value={inviteEmail}
                  onChange={e => setInviteEmail(e.target.value)}
                  placeholder="Invite player by email..."
                  style={{ flex: 1 }}
                />
                <button type="submit" className="btn-gold" disabled={inviting}>
                  {inviting ? 'Inviting...' : 'Invite'}
                </button>
              </form>
            )}
            {inviteError && (
              <div style={{ marginBottom: 'var(--space-4)', background: 'rgba(155,28,28,0.15)', border: '1px solid var(--color-blood)', borderRadius: 'var(--radius-md)', padding: 'var(--space-3)', fontSize: 'var(--text-sm)', color: '#fca5a5', fontFamily: 'var(--font-heading)' }}>
                {inviteError}
              </div>
            )}
            <div className="section-header">Players ({members.length})</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-2)' }}>
              {members.map(m => (
                <div key={m.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: 'var(--space-3) var(--space-4)', background: 'var(--bg-raised)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-subtle)' }}>
                  <div>
                    <div style={{ fontFamily: 'var(--font-heading)', fontWeight: 600, color: 'var(--text-primary)', fontSize: 'var(--text-sm)' }}>
                      {m.display_name ?? m.email}
                      {m.user_id === user?.id && <span style={{ color: 'var(--text-muted)', marginLeft: 'var(--space-2)' }}>(you)</span>}
                    </div>
                    {m.display_name && <div style={{ fontSize: 'var(--text-xs)', color: 'var(--text-muted)' }}>{m.email}</div>}
                  </div>
                  <div style={{ display: 'flex', gap: 'var(--space-2)', alignItems: 'center' }}>
                    <span className={m.role === 'dm' ? 'badge badge-gold' : 'badge badge-muted'}>{m.role.toUpperCase()}</span>
                    {isOwner && m.user_id !== campaign.owner_id && (
                      <button className="btn-ghost btn-sm" onClick={() => removeMember(m.user_id)} style={{ color: 'var(--color-ash)' }}>
                        Remove
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Characters tab */}
        {activeTab === 'characters' && (
          <div>
            {characters.length === 0 ? (
              <div className="card" style={{ textAlign: 'center', padding: 'var(--space-8)' }}>
                <p style={{ color: 'var(--text-muted)', fontFamily: 'var(--font-heading)' }}>
                  No characters assigned to this campaign yet. Players can assign their characters from the character sheet.
                </p>
              </div>
            ) : (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))', gap: 'var(--space-4)' }}>
                {characters.map(c => (
                  <div key={c.id} className="card">
                    <div style={{ fontFamily: 'var(--font-heading)', fontWeight: 700, fontSize: 'var(--text-md)', marginBottom: 'var(--space-1)' }}>{c.name}</div>
                    <div style={{ fontSize: 'var(--text-xs)', color: 'var(--text-muted)', fontFamily: 'var(--font-heading)', marginBottom: 'var(--space-3)' }}>
                      Level {c.level} {c.class_name} — {c.species}
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--text-sm)' }}>
                      <span style={{ color: c.current_hp > c.max_hp * 0.5 ? 'var(--hp-full)' : 'var(--hp-low)' }}>
                        {c.current_hp}/{c.max_hp} HP
                      </span>
                      <span style={{ color: 'var(--text-muted)' }}>AC {c.armor_class}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Session tab — real-time combat state */}
        {activeTab === 'session' && (
          <div style={{ maxWidth: 640 }}>
            {!sessionState ? (
              <div className="card" style={{ textAlign: 'center', padding: 'var(--space-8)' }}>
                <p style={{ color: 'var(--text-muted)', fontFamily: 'var(--font-heading)', marginBottom: 'var(--space-4)' }}>
                  No active session. Start combat to begin tracking.
                </p>
                {isOwner && (
                  <button className="btn-primary" onClick={toggleCombat}>Start Combat Session</button>
                )}
              </div>
            ) : (
              <div>
                <div style={{ display: 'flex', gap: 'var(--space-4)', marginBottom: 'var(--space-6)' }}>
                  <div className="stat-box">
                    <div className="stat-box-label">Round</div>
                    <div className="stat-box-value">{sessionState.round}</div>
                  </div>
                  <div className="stat-box">
                    <div className="stat-box-label">Combatants</div>
                    <div className="stat-box-value">{sessionState.initiative_order.length}</div>
                  </div>
                  <div className="stat-box">
                    <div className="stat-box-label">Status</div>
                    <div className="stat-box-value" style={{ fontSize: 'var(--text-sm)', color: sessionState.combat_active ? 'var(--color-crimson-bright)' : 'var(--hp-full)' }}>
                      {sessionState.combat_active ? 'Active' : 'Ended'}
                    </div>
                  </div>
                </div>

                <div className="section-header">Initiative Order</div>
                {sessionState.initiative_order.length === 0 ? (
                  <p style={{ color: 'var(--text-muted)', fontFamily: 'var(--font-heading)', fontSize: 'var(--text-sm)' }}>No combatants added yet.</p>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-2)' }}>
                    {[...sessionState.initiative_order]
                      .sort((a, b) => b.initiative - a.initiative)
                      .map((c, idx) => {
                        const isActive = idx === sessionState.current_turn % sessionState.initiative_order.length;
                        const hpPct = c.max_hp > 0 ? c.current_hp / c.max_hp : 0;
                        return (
                          <div key={c.id} style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)', padding: 'var(--space-3) var(--space-4)', borderRadius: 'var(--radius-md)', border: isActive ? '2px solid var(--color-gold)' : '1px solid var(--border-subtle)', background: isActive ? 'rgba(201,146,42,0.07)' : 'var(--bg-surface)' }}>
                            <span style={{ fontFamily: 'var(--font-heading)', fontWeight: 700, color: 'var(--text-gold)', minWidth: 24, textAlign: 'center' }}>{c.initiative}</span>
                            <span style={{ fontFamily: 'var(--font-heading)', flex: 1, color: isActive ? 'var(--text-gold)' : 'var(--text-primary)' }}>{c.name}</span>
                            <span style={{ fontSize: 'var(--text-sm)', color: hpPct > 0.5 ? 'var(--hp-full)' : hpPct > 0.25 ? 'var(--hp-mid)' : 'var(--hp-low)' }}>
                              {c.current_hp}/{c.max_hp}
                            </span>
                            <span style={{ fontSize: 'var(--text-xs)', color: 'var(--text-muted)' }}>AC {c.ac}</span>
                            {c.conditions.length > 0 && <span className="badge badge-crimson">{c.conditions.length}</span>}
                          </div>
                        );
                      })
                    }
                  </div>
                )}
                <p style={{ marginTop: 'var(--space-4)', fontSize: 'var(--text-xs)', color: 'var(--text-muted)', fontFamily: 'var(--font-heading)' }}>
                  This view syncs in real-time. All players see the same session state.
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
