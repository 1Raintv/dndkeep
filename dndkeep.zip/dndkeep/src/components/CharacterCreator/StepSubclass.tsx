import type { SubclassData } from '../../types';
import { CLASS_MAP } from '../../data/classes';

interface StepSubclassProps {
  className: string;
  selected: string;
  onSelect: (subclass: string) => void;
}

export default function StepSubclass({ className, selected, onSelect }: StepSubclassProps) {
  const cls = CLASS_MAP[className];
  if (!cls) return null;

  const level1Subclasses = cls.subclasses.filter(sc => sc.unlock_level <= 1);

  // Classes that pick subclass later — show informational panel
  if (level1Subclasses.length === 0) {
    const firstUnlockLevel = cls.subclasses[0]?.unlock_level ?? 3;
    return (
      <div className="card" style={{ maxWidth: 540 }}>
        <h3 style={{ marginBottom: 'var(--space-4)' }}>{className} Subclass</h3>
        <p style={{ color: 'var(--text-secondary)' }}>
          {className}s choose their subclass at level {firstUnlockLevel}.
          You will select one when you reach that level.
        </p>
        <div style={{ marginTop: 'var(--space-6)' }}>
          <div className="section-header">Available at Level {firstUnlockLevel}</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
            {cls.subclasses.map(sc => (
              <SubclassCard key={sc.name} subclass={sc} selected={false} onSelect={() => {}} disabled />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 640 }}>
      <p style={{ color: 'var(--text-muted)', fontSize: 'var(--text-sm)', marginBottom: 'var(--space-4)', fontFamily: 'var(--font-heading)' }}>
        {className}s choose their subclass at character creation.
      </p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
        {cls.subclasses.map(sc => (
          <SubclassCard key={sc.name} subclass={sc} selected={selected === sc.name} onSelect={onSelect} disabled={false} />
        ))}
      </div>
    </div>
  );
}

function SubclassCard({ subclass, selected, onSelect, disabled }: {
  subclass: SubclassData;
  selected: boolean;
  onSelect: (name: string) => void;
  disabled: boolean;
}) {
  return (
    <button
      onClick={() => !disabled && onSelect(subclass.name)}
      disabled={disabled}
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: 'var(--space-1)',
        padding: 'var(--space-4)',
        borderRadius: 'var(--radius-md)',
        border: selected ? '2px solid var(--color-gold)' : '1px solid var(--border-subtle)',
        background: selected ? 'rgba(201,146,42,0.1)' : 'var(--bg-sunken)',
        cursor: disabled ? 'default' : 'pointer',
        transition: 'all var(--transition-fast)',
        textAlign: 'left',
        opacity: disabled ? 0.6 : 1,
      }}
    >
      <div style={{ fontFamily: 'var(--font-heading)', fontWeight: 700, fontSize: 'var(--text-md)', color: selected ? 'var(--text-gold)' : 'var(--text-primary)' }}>
        {subclass.name}
      </div>
      <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-secondary)' }}>
        {subclass.description}
      </div>
    </button>
  );
}
