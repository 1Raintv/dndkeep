import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { Campaign } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { CampaignProvider } from '../../context/CampaignContext';
import CampaignList from '../Campaign/CampaignList';
import CampaignDashboard from '../Campaign/CampaignDashboard';

function CampaignsContent() {
  const [selected, setSelected] = useState<Campaign | null>(null);

  if (selected) {
    return <CampaignDashboard campaign={selected} onBack={() => setSelected(null)} />;
  }

  return <CampaignList onSelect={setSelected} />;
}

export default function CampaignsPage() {
  const { isPro, loading } = useAuth();
  const navigate = useNavigate();

  if (loading) {
    return (
      <div style={{ display: 'flex', gap: 'var(--space-3)', alignItems: 'center', padding: 'var(--space-8)' }}>
        <div className="spinner" /><span className="loading-text">Loading...</span>
      </div>
    );
  }

  if (!isPro) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', padding: 'var(--space-16) var(--space-4)' }}>
        <div className="card card-gold" style={{ maxWidth: 480, textAlign: 'center' }}>
          <h2 style={{ marginBottom: 'var(--space-4)' }}>Campaigns</h2>
          <p style={{ color: 'var(--text-secondary)', marginBottom: 'var(--space-6)' }}>
            Campaign management is a Pro feature. Upgrade to create campaigns, invite players, assign DM roles, and sync combat in real-time.
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-2)', marginBottom: 'var(--space-8)', textAlign: 'left' }}>
            {[
              'Unlimited characters across all campaigns',
              'Invite players by email',
              'DM and player role management',
              'Real-time combat sync — every player sees initiative live',
              'Shared session state for remote play',
            ].map(f => (
              <div key={f} style={{ display: 'flex', gap: 'var(--space-2)', fontSize: 'var(--text-sm)' }}>
                <span style={{ color: 'var(--color-gold)', fontFamily: 'var(--font-heading)' }}>+</span>
                <span style={{ color: 'var(--text-secondary)' }}>{f}</span>
              </div>
            ))}
          </div>
          <button className="btn-gold btn-lg" style={{ width: '100%', justifyContent: 'center' }} onClick={() => navigate('/settings')}>
            Upgrade to Pro
          </button>
        </div>
      </div>
    );
  }

  return (
    <CampaignProvider>
      <CampaignsContent />
    </CampaignProvider>
  );
}
